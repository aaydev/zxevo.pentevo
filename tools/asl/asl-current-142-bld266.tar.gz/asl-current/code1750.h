#ifndef _CODE1750_H
#define _CODE1750_H
/* code1750.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator MIL STD 1750                                                */
/*                                                                           */
/*****************************************************************************/

extern void code1750_init(void);

#endif /* _CODE1750_H */
