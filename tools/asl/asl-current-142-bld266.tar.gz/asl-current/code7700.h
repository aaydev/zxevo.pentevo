#ifndef _CODE7700_H
#define _CODE7700_H
/* code7700.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS-Codegeneratormodul MELPS-7700                                          */
/*                                                                           */
/* Historie: 5.11.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code7700_init(void);
#endif /* _CODE7700_H */
