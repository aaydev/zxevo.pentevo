#ifndef _CODEFMC16_H
#define _CODEFMC16_H
/* codefmc16.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS, C-Version                                                             */
/*                                                                           */
/* Codegenerator fuer Fujitsu-F2MC16-Prozessoren                             */
/*                                                                           */
/* Historie: 19.11.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codef2mc16_init(void);
#endif /* _CODEFMC16_H */
