#ifndef _CODE78K4_H
#define _CODE78K4_H
/* code78k4.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Code Generator 78K4 Family                                                */
/*                                                                           */
/*****************************************************************************/

extern void code78k4_init(void);

#endif /* _CODE78K4_H */
