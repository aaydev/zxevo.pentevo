#ifndef _CODE68K_H
#define _CODE68K_H
/* code68k.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 680x0-Familie                                               */
/*                                                                           */
/* Historie:  9. 9.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code68k_init(void);
#endif /* _CODE68K_H */
