#ifndef _CODEOLMS40_H
#define _CODEOLMS40_H
/* codeol40.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator OKI OLMS-40                                                 */
/*                                                                           */
/*****************************************************************************/

extern void codeolms40_init(void);
#endif /* _CODEOLMS40_H */
