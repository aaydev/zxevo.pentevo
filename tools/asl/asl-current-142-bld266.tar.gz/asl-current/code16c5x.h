#ifndef _CODE16C5X_H
#define _CODE16C5X_H
/* code16c5x.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS - Codegenerator fuer PIC16C5x                                          */
/*                                                                           */
/* Historie: 19.8.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code16c5x_init(void);

#endif /* _CODE16C5X_H */
