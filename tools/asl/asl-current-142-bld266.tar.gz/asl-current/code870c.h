#ifndef _CODE87C800C_H
#define _CODE87C800C_H
/* code870c.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TLCS-870/C                                                  */
/*                                                                           */
/*                                                                           */
/*****************************************************************************/

extern void code870c_init(void);
#endif /* _CODE87C800C_H */
