#ifndef _CODEZ8000_HPP
#define _CODEZ8000_HPP

/* Declare this in a header file so CLang++ does not complain
   about unused inline functions: */

# include "cppops.h"
DefCPPOps_Mask(tCtlFlags)

#endif /* _CODEZ8000_HPP */
