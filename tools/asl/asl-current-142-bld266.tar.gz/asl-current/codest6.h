#ifndef _CODEST6_H
#define _CODEST6_H
/* codest6.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator ST6-Familie                                                 */
/*                                                                           */
/* Historie: 14.11.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codest6_init(void);
#endif /* _CODEST6_H */
