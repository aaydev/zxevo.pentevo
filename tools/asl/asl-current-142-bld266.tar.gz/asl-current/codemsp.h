#ifndef _CODEMSP_H
#define _CODEMSP_H
/* codemsp.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator MSP430                                                      */
/*                                                                           */
/* Historie:                                                                 */
/*                                                                           */
/*****************************************************************************/

extern void codemsp_init(void);
#endif /* _CODEMSP_H */
