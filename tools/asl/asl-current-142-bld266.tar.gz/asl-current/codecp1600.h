#ifndef _CODECP1600_H
#define _CODECP1600_H
/* codecp1600.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator GI CP-1600                                                  */
/*                                                                           */
/*****************************************************************************/

extern void codecp1600_init(void);
#endif /* _CODECP1600_H */
