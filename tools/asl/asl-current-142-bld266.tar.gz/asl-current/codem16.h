#ifndef _CODEM16_H
#define _CODEM16_H
/* codem16.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Mitsubishi M16                                              */
/*                                                                           */
/* Historie: 27.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codem16_init(void);
#endif /* _CODEM16_H */
