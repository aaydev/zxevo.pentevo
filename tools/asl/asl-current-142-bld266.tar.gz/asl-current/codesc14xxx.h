#ifndef _CODESC14XXX_H
#define _CODESC14XXX_H
/* codesc14xxx.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator SC14xxx                                                     */
/*                                                                           */
/* Historie: 25. 3.1999 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codesc14xxx_init(void);
#endif /* _CODESC14XXX_H */
