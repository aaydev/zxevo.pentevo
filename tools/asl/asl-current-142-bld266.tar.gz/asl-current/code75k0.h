#ifndef _CODE75K0_H
#define _CODE75K0_H
/* code75k0.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator NEC 75K0                                                    */
/*                                                                           */
/* Historie: 31.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code75k0_init(void);
#endif /* _CODE75K0_H */
