#ifndef _CODE68_H
#define _CODE68_H
/* code68.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator fuer 68xx-Prozessoren                                       */
/*                                                                           */
/* Historie:  13.8.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code68_init(void);
#endif /* _CODE68_H */
