#ifndef _CODE960_H
#define _CODE960_H
/* code960.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* Makroassembler AS                                                         */
/*                                                                           */
/* Codegenerator i960-Familie                                                */
/*                                                                           */
/* Historie: 24.8.1998 angelegt                                              */
/*                                                                           */
/*****************************************************************************/

extern void code960_init(void);
#endif /* _CODE960_H */
