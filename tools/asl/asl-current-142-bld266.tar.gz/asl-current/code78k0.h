#ifndef _CODE78K0_H
#define _CODE78K0_H
/* code78k0.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator 78K0-Familie                                                */
/*                                                                           */
/* Historie: 1.12.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code78k0_init(void);
#endif /* _CODE78K0_H */
