#ifndef _CODE3254X_H
#define _CODE3254X_H
/* code3254x.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* Macro Assembler AS                                                        */
/*                                                                           */
/* code generator for TI C54x DSP devices                                    */
/*                                                                           */
/* history:  2001-07-07: begun                                               */
/*                                                                           */
/*****************************************************************************/

extern void code32054x_init(void);
#endif /* _CODE3254X_H */
