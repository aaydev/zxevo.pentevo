#ifndef _CODE16C8X_H
#define _CODE16C8X_H
/* code16c8x.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS-Codegenerator PIC16C8x                                                 */
/*                                                                           */
/* Historie: 21.8.1996 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code16c8x_init(void);
#endif /* _CODE16C8X_H */
