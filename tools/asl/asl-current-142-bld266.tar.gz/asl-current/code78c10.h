#ifndef _CODE78C10_H
#define _CODE78C10_H
/* code78c10.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator NEC uPD78(C)1x                                              */
/*                                                                           */
/* Historie: 29.12.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code78c10_init(void);
#endif /* _CODE78C10_H */
