#ifndef _CODEMN1610_H
#define _CODEMN1610_H
/* codemn1610.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator Panafacom MN1610 / MN1613                                   */
/*                                                                           */
/*****************************************************************************/

extern void codemn1610_init(void);
#endif /* _CODEMN1610_H */
