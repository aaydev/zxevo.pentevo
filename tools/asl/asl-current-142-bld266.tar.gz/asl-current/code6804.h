#ifndef _CODE6804_H
#define _CODE6804_H
/* code6804.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS-Codeenerator Motorola/ST 6804                                          */
/*                                                                           */
/* Historie: 17.10.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code6804_init(void);
#endif /* _CODE6804_H */
