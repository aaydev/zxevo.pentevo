#ifndef _CODE29K_H
#define _CODE29K_H
/* code29k.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator AM29xxx-Familie                                             */
/*                                                                           */
/* Historie: 18.11.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void code29k_init(void);
#endif /* _CODE29K_H */
