#ifndef _CODEST9_H
#define _CODEST9_H
/* codest9.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator SGS-Thomson ST9                                             */
/*                                                                           */
/* Historie: 10.2.1997 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void codest9_init(void);
#endif /* _CODEST9_H */
