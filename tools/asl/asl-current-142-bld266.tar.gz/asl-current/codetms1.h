#ifndef _CODETMS1_H
#define _CODETMS1_H
/* codetms1.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TMS1000-Familie                                             */
/*                                                                           */
/*****************************************************************************/

extern void codetms1_init(void);

#endif /* _CODETMS1_H */
