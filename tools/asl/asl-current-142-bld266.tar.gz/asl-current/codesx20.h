#ifndef _CODE_SX20_H
#define _CODE_SX20_H
/* codesx20.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* AS - Target Parallax SX20                                                 */
/*                                                                           */
/*****************************************************************************/

extern void codesx20_init(void);

#endif /* _CODE_SX20_H */
