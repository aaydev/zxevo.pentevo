#ifndef _CODEH8_3_H
#define _CODEH8_3_H
/* codeh8_3.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator H8/300(L/H)                                                 */
/*                                                                           */
/* Historie: 22.11.1996 Grundsteinlegung                                     */
/*                                                                           */
/*****************************************************************************/

extern void codeh8_3_init(void);
#endif /* _CODEH8_3_H */
