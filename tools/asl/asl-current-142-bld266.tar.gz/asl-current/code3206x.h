#ifndef _CODE3206X_H
#define _CODE3206X_H
/* code3206x.h */
/*****************************************************************************/
/* SPDX-License-Identifier: GPL-2.0-only OR GPL-3.0-only                     */
/*                                                                           */
/* AS-Portierung                                                             */
/*                                                                           */
/* Codegenerator TMS320C6x-Familie                                           */
/*                                                                           */
/* Historie: 24.2.1998 Grundsteinlegung                                      */
/*                                                                           */
/*****************************************************************************/

extern void code3206x_init(void);

#endif /* _CODE3206X_H */
